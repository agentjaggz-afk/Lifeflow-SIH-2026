import { useState, useEffect, useCallback } from 'react';
import {
  ArrowLeft, Droplet, Users, Building2, Calendar, Phone, MapPin,
  Plus, AlertCircle, CheckCircle2, Clock, Heart, Activity, Search,
  TrendingUp, TrendingDown, X,
} from 'lucide-react';
import {
  db,
  BLOOD_GROUPS,
  type BloodGroup,
  type BloodInventory,
  type Donor,
  type BloodRequest,
  type BloodCamp,
  type Hospital,
} from '@/lib/data';

interface DonorReceiverViewProps {
  city: string;
  coords: { lat: number; lng: number } | null;
  onBack: () => void;
  onSelectHospital: (hospital: Hospital) => void;
}

type Tab = 'dashboard' | 'donors' | 'requests' | 'camps';

export function DonorReceiverView({ city, coords, onBack, onSelectHospital }: DonorReceiverViewProps) {
  const [tab, setTab] = useState<Tab>('dashboard');
  const [inventory, setInventory] = useState<BloodInventory[]>([]);
  const [donors, setDonors] = useState<Donor[]>([]);
  const [requests, setRequests] = useState<BloodRequest[]>([]);
  const [camps, setCamps] = useState<BloodCamp[]>([]);
  const [hospitals, setHospitals] = useState<Hospital[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchData = useCallback(async () => {
    setLoading(true);
    const [invRes, donorRes, reqRes, campRes, hospRes] = await Promise.all([
      db
        .from('blood_inventory')
        .select('*, hospital:hospitals(*)')
        .ilike('hospitals.city', `%${city}%`),
      db.from('donors').select('*').ilike('city', `%${city}%`).order('created_at', { ascending: false }),
      db.from('blood_requests').select('*, hospital:hospitals(*)').ilike('city', `%${city}%`).order('created_at', { ascending: false }),
      db.from('blood_camps').select('*, hospital:hospitals(*)').ilike('city', `%${city}%`).order('date', { ascending: true }),
      db.from('hospitals').select('*').ilike('city', `%${city}%`).order('name'),
    ]);

    setInventory((invRes.data as BloodInventory[]) || []);
    setDonors((donorRes.data as Donor[]) || []);
    setRequests((reqRes.data as BloodRequest[]) || []);
    setCamps((campRes.data as BloodCamp[]) || []);
    setHospitals((hospRes.data as Hospital[]) || []);
    setLoading(false);
  }, [city]);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  // Realtime subscriptions
  useEffect(() => {
    const invChannel = db
      .channel('inventory-changes')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'blood_inventory' }, () => fetchData())
      .subscribe();
    const donorChannel = db
      .channel('donor-changes')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'donors' }, () => fetchData())
      .subscribe();
    const reqChannel = db
      .channel('request-changes')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'blood_requests' }, () => fetchData())
      .subscribe();
    const campChannel = db
      .channel('camp-changes')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'blood_camps' }, () => fetchData())
      .subscribe();

    return () => {
      db.removeChannel(invChannel);
      db.removeChannel(donorChannel);
      db.removeChannel(reqChannel);
      db.removeChannel(campChannel);
    };
  }, [fetchData]);

  return (
    <div className="min-h-screen bg-[#fdf6f3]">
      {/* Header */}
      <header className="sticky top-0 z-30 border-b border-gray-100 bg-white/80 backdrop-blur-lg">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-3 md:px-6">
          <div className="flex items-center gap-3">
            <button onClick={onBack} className="btn-ghost">
              <ArrowLeft className="h-4 w-4" />
              <span className="hidden sm:inline">Change Location</span>
            </button>
            <div className="flex items-center gap-2 rounded-full bg-primary-50 px-3 py-1.5 ring-1 ring-primary-100">
              <MapPin className="h-3.5 w-3.5 text-primary-600" />
              <span className="text-sm font-semibold text-primary-700">{city}</span>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-primary-600">
              <Droplet className="h-5 w-5 text-white" fill="white" />
            </div>
            <span className="text-lg font-bold text-gray-900">LifeFlow</span>
          </div>
        </div>
        {/* Tabs */}
        <div className="mx-auto max-w-7xl px-4 md:px-6">
          <nav className="flex gap-1 overflow-x-auto pb-px">
            {[
              { id: 'dashboard' as Tab, label: 'Dashboard', icon: Activity },
              { id: 'donors' as Tab, label: 'Donors', icon: Users },
              { id: 'requests' as Tab, label: 'Blood Requests', icon: AlertCircle },
              { id: 'camps' as Tab, label: 'Donation Camps', icon: Calendar },
            ].map((t) => (
              <button
                key={t.id}
                onClick={() => setTab(t.id)}
                className={`flex items-center gap-2 border-b-2 px-4 py-2.5 text-sm font-medium transition-colors ${
                  tab === t.id
                    ? 'border-primary-600 text-primary-700'
                    : 'border-transparent text-gray-500 hover:text-gray-800'
                }`}
              >
                <t.icon className="h-4 w-4" />
                {t.label}
              </button>
            ))}
          </nav>
        </div>
      </header>

      <main className="mx-auto max-w-7xl px-4 py-6 md:px-6">
        {loading ? (
          <div className="flex h-64 items-center justify-center">
            <div className="flex flex-col items-center gap-3">
              <div className="h-8 w-8 animate-spin rounded-full border-2 border-primary-200 border-t-primary-600" />
              <p className="text-sm text-gray-500">Loading real-time data...</p>
            </div>
          </div>
        ) : (
          <>
            {tab === 'dashboard' && (
              <Dashboard inventory={inventory} donors={donors} requests={requests} hospitals={hospitals} onSelectHospital={onSelectHospital} />
            )}
            {tab === 'donors' && <DonorsTab donors={donors} city={city} onRefresh={fetchData} />}
            {tab === 'requests' && <RequestsTab requests={requests} city={city} hospitals={hospitals} onRefresh={fetchData} />}
            {tab === 'camps' && <CampsTab camps={camps} />}
          </>
        )}
      </main>
    </div>
  );
}

/* ============ Dashboard ============ */

function Dashboard({
  inventory,
  donors,
  requests,
  hospitals,
  onSelectHospital,
}: {
  inventory: BloodInventory[];
  donors: Donor[];
  requests: BloodRequest[];
  hospitals: Hospital[];
  onSelectHospital: (h: Hospital) => void;
}) {
  const openRequests = requests.filter((r) => r.status === 'Open');
  const availableDonors = donors.filter((d) => d.is_available);
  const totalUnits = inventory.reduce((sum, i) => sum + i.units_available, 0);
  const totalNeeded = inventory.reduce((sum, i) => sum + i.units_needed, 0);

  // Aggregate by blood group
  const byGroup = BLOOD_GROUPS.map((group) => {
    const items = inventory.filter((i) => i.blood_group === group);
    const available = items.reduce((s, i) => s + i.units_available, 0);
    const needed = items.reduce((s, i) => s + i.units_needed, 0);
    return { group, available, needed };
  });

  const maxUnits = Math.max(...byGroup.map((g) => g.available + g.needed), 1);

  return (
    <div className="animate-fade-in space-y-6">
      {/* Stat cards */}
      <div className="grid grid-cols-2 gap-4 md:grid-cols-4">
        <StatCard icon={Droplet} label="Total Units Available" value={totalUnits} color="primary" trend="up" />
        <StatCard icon={AlertCircle} label="Units Needed" value={totalNeeded} color="warning" trend="down" />
        <StatCard icon={Users} label="Available Donors" value={availableDonors.length} color="success" trend="up" />
        <StatCard icon={Heart} label="Open Requests" value={openRequests.length} color="error" trend="down" />
      </div>

      {/* Blood group chart */}
      <div className="card p-6">
        <div className="mb-5 flex items-center justify-between">
          <div>
            <h3 className="text-lg font-bold text-gray-900">Blood Group Availability</h3>
            <p className="text-sm text-gray-500">Real-time inventory across all hospitals</p>
          </div>
          <div className="flex items-center gap-4 text-xs">
            <span className="flex items-center gap-1.5">
              <span className="h-2.5 w-2.5 rounded-full bg-success-500" /> Available
            </span>
            <span className="flex items-center gap-1.5">
              <span className="h-2.5 w-2.5 rounded-full bg-warning-400" /> Needed
            </span>
          </div>
        </div>
        <div className="grid grid-cols-4 gap-4 md:grid-cols-8">
          {byGroup.map((g) => (
            <div key={g.group} className="flex flex-col items-center">
              <div className="relative flex h-40 w-full items-end justify-center">
                <div className="flex w-full max-w-[40px] flex-col-reverse gap-px overflow-hidden rounded-lg">
                  <div
                    className="w-full bg-gradient-to-t from-success-500 to-success-400 transition-all duration-500"
                    style={{ height: `${(g.available / maxUnits) * 140}px` }}
                  />
                  {g.needed > 0 && (
                    <div
                      className="w-full bg-gradient-to-t from-warning-500 to-warning-300 transition-all duration-500"
                      style={{ height: `${(g.needed / maxUnits) * 40}px` }}
                    />
                  )}
                </div>
              </div>
              <span className="mt-2 text-sm font-bold text-gray-900">{g.group}</span>
              <span className="text-xs text-gray-500">{g.available} units</span>
            </div>
          ))}
        </div>
      </div>

      {/* Two column: urgent requests + hospitals */}
      <div className="grid gap-6 lg:grid-cols-2">
        {/* Urgent requests */}
        <div className="card p-6">
          <div className="mb-4 flex items-center justify-between">
            <h3 className="text-lg font-bold text-gray-900">Urgent Blood Requests</h3>
            <span className="badge bg-error-50 text-error-600">{openRequests.length} open</span>
          </div>
          <div className="space-y-3">
            {openRequests.length === 0 ? (
              <p className="py-8 text-center text-sm text-gray-400">No open requests right now.</p>
            ) : (
              openRequests.slice(0, 5).map((r) => (
                <div key={r.id} className="flex items-center gap-3 rounded-xl bg-gray-50 p-3">
                  <div
                    className={`flex h-12 w-12 shrink-0 items-center justify-center rounded-xl text-sm font-bold ${
                      r.urgency === 'Critical'
                        ? 'bg-error-100 text-error-700'
                        : r.urgency === 'Urgent'
                          ? 'bg-warning-100 text-warning-700'
                          : 'bg-primary-100 text-primary-700'
                    }`}
                  >
                    {r.blood_group}
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-sm font-semibold text-gray-900">{r.patient_name}</p>
                    <p className="text-xs text-gray-500">
                      {r.units_needed} units needed · {r.urgency}
                    </p>
                  </div>
                  <span className="flex items-center gap-1 text-xs text-gray-400">
                    <Clock className="h-3 w-3" />
                    {timeAgo(r.created_at)}
                  </span>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Hospitals */}
        <div className="card p-6">
          <div className="mb-4 flex items-center justify-between">
            <h3 className="text-lg font-bold text-gray-900">Hospitals in Your Area</h3>
            <span className="badge bg-primary-50 text-primary-600">{hospitals.length} total</span>
          </div>
          <div className="space-y-3">
            {hospitals.length === 0 ? (
              <p className="py-8 text-center text-sm text-gray-400">No hospitals registered yet.</p>
            ) : (
              hospitals.map((h) => {
                const hospInv = inventory.filter((i) => i.hospital_id === h.id);
                const hospUnits = hospInv.reduce((s, i) => s + i.units_available, 0);
                return (
                  <button
                    key={h.id}
                    onClick={() => onSelectHospital(h)}
                    className="flex w-full items-center gap-3 rounded-xl bg-gray-50 p-3 text-left transition-all hover:bg-primary-50 hover:ring-1 hover:ring-primary-200"
                  >
                    <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-primary-100">
                      <Building2 className="h-5 w-5 text-primary-600" />
                    </div>
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-sm font-semibold text-gray-900">{h.name}</p>
                      <p className="truncate text-xs text-gray-500">{h.address}, {h.city}</p>
                    </div>
                    <div className="text-right">
                      <p className="text-sm font-bold text-success-600">{hospUnits}</p>
                      <p className="text-xs text-gray-400">units</p>
                    </div>
                  </button>
                );
              })
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

function StatCard({
  icon: Icon,
  label,
  value,
  color,
  trend,
}: {
  icon: React.ComponentType<{ className?: string }>;
  label: string;
  value: number;
  color: 'primary' | 'success' | 'warning' | 'error';
  trend: 'up' | 'down';
}) {
  const colorClasses = {
    primary: 'bg-primary-50 text-primary-600',
    success: 'bg-success-50 text-success-600',
    warning: 'bg-warning-50 text-warning-600',
    error: 'bg-error-50 text-error-600',
  };
  return (
    <div className="card p-4 md:p-5">
      <div className="flex items-start justify-between">
        <div className={`flex h-10 w-10 items-center justify-center rounded-xl ${colorClasses[color]}`}>
          <Icon className="h-5 w-5" />
        </div>
        {trend === 'up' ? (
          <TrendingUp className="h-4 w-4 text-success-500" />
        ) : (
          <TrendingDown className="h-4 w-4 text-error-500" />
        )}
      </div>
      <p className="mt-3 text-2xl font-bold text-gray-900">{value}</p>
      <p className="text-xs text-gray-500">{label}</p>
    </div>
  );
}

/* ============ Donors Tab ============ */

function DonorsTab({ donors, city, onRefresh }: { donors: Donor[]; city: string; onRefresh: () => void }) {
  const [showForm, setShowForm] = useState(false);
  const [search, setSearch] = useState('');
  const [filterGroup, setFilterGroup] = useState<BloodGroup | 'all'>('all');

  const filtered = donors.filter((d) => {
    const matchSearch =
      d.name.toLowerCase().includes(search.toLowerCase()) ||
      d.blood_group.toLowerCase().includes(search.toLowerCase());
    const matchGroup = filterGroup === 'all' || d.blood_group === filterGroup;
    return matchSearch && matchGroup;
  });

  return (
    <div className="animate-fade-in space-y-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h2 className="text-xl font-bold text-gray-900">Registered Donors</h2>
          <p className="text-sm text-gray-500">{donors.length} donors in {city}</p>
        </div>
        <button onClick={() => setShowForm(true)} className="btn-primary">
          <Plus className="h-4 w-4" />
          Register as Donor
        </button>
      </div>

      {/* Filters */}
      <div className="flex flex-wrap items-center gap-3">
        <div className="relative flex-1 min-w-[200px]">
          <Search className="absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-400" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search by name or blood group..."
            className="input pl-10"
          />
        </div>
        <select
          value={filterGroup}
          onChange={(e) => setFilterGroup(e.target.value as BloodGroup | 'all')}
          className="input w-auto min-w-[140px]"
        >
          <option value="all">All Groups</option>
          {BLOOD_GROUPS.map((g) => (
            <option key={g} value={g}>{g}</option>
          ))}
        </select>
      </div>

      {/* Donor list */}
      <div className="grid gap-3 md:grid-cols-2 lg:grid-cols-3">
        {filtered.length === 0 ? (
          <div className="col-span-full py-16 text-center">
            <Users className="mx-auto mb-3 h-10 w-10 text-gray-300" />
            <p className="text-sm text-gray-400">No donors found. Be the first to register!</p>
          </div>
        ) : (
          filtered.map((d) => (
            <div key={d.id} className="card p-4">
              <div className="flex items-start gap-3">
                <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-primary-100 text-sm font-bold text-primary-700">
                  {d.blood_group}
                </div>
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-2">
                    <p className="truncate text-sm font-semibold text-gray-900">{d.name}</p>
                    {d.is_available ? (
                      <span className="badge bg-success-50 text-success-600">Available</span>
                    ) : (
                      <span className="badge bg-gray-100 text-gray-500">Unavailable</span>
                    )}
                  </div>
                  <div className="mt-1 flex items-center gap-1 text-xs text-gray-500">
                    <MapPin className="h-3 w-3" /> {d.city}
                  </div>
                  {d.last_donated && (
                    <p className="mt-1 text-xs text-gray-400">Last donated: {d.last_donated}</p>
                  )}
                </div>
              </div>
              <div className="mt-3 flex items-center gap-2 border-t border-gray-50 pt-3">
                <a href={`tel:${d.phone}`} className="btn-ghost flex-1 text-xs">
                  <Phone className="h-3.5 w-3.5" /> Call
                </a>
              </div>
            </div>
          ))
        )}
      </div>

      {showForm && (
        <DonorFormModal city={city} onClose={() => setShowForm(false)} onSaved={() => { setShowForm(false); onRefresh(); }} />
      )}
    </div>
  );
}

function DonorFormModal({ city, onClose, onSaved }: { city: string; onClose: () => void; onSaved: () => void }) {
  const [form, setForm] = useState({
    name: '',
    blood_group: 'O+' as BloodGroup,
    phone: '',
    email: '',
  });
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.name.trim() || !form.phone.trim()) {
      setError('Name and phone are required.');
      return;
    }
    setSaving(true);
    setError(null);
    const { error: insertError } = await db.from('donors').insert({
      name: form.name.trim(),
      blood_group: form.blood_group,
      city,
      phone: form.phone.trim(),
      email: form.email.trim() || null,
      is_available: true,
    });
    setSaving(false);
    if (insertError) {
      setError('Failed to register. Please try again.');
      return;
    }
    onSaved();
  };

  return (
    <Modal onClose={onClose} title="Register as Donor">
      <form onSubmit={handleSubmit} className="space-y-4">
        {error && <div className="rounded-lg bg-error-50 px-4 py-2 text-sm text-error-600">{error}</div>}
        <div>
          <label className="label">Full Name *</label>
          <input className="input" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="John Doe" />
        </div>
        <div>
          <label className="label">Blood Group *</label>
          <select className="input" value={form.blood_group} onChange={(e) => setForm({ ...form, blood_group: e.target.value as BloodGroup })}>
            {BLOOD_GROUPS.map((g) => (
              <option key={g} value={g}>{g}</option>
            ))}
          </select>
        </div>
        <div>
          <label className="label">Phone Number *</label>
          <input className="input" value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} placeholder="+1 234 567 890" />
        </div>
        <div>
          <label className="label">Email (optional)</label>
          <input className="input" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} placeholder="john@example.com" />
        </div>
        <div className="flex gap-3 pt-2">
          <button type="button" onClick={onClose} className="btn-secondary flex-1">Cancel</button>
          <button type="submit" disabled={saving} className="btn-primary flex-1">
            {saving ? 'Registering...' : 'Register'}
          </button>
        </div>
      </form>
    </Modal>
  );
}

/* ============ Requests Tab ============ */

function RequestsTab({
  requests,
  city,
  hospitals,
  onRefresh,
}: {
  requests: BloodRequest[];
  city: string;
  hospitals: Hospital[];
  onRefresh: () => void;
}) {
  const [showForm, setShowForm] = useState(false);

  const sorted = [...requests].sort((a, b) => {
    const urgencyOrder = { Critical: 0, Urgent: 1, Normal: 2 };
    return urgencyOrder[a.urgency] - urgencyOrder[b.urgency];
  });

  return (
    <div className="animate-fade-in space-y-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h2 className="text-xl font-bold text-gray-900">Blood Requests</h2>
          <p className="text-sm text-gray-500">{requests.filter((r) => r.status === 'Open').length} open requests</p>
        </div>
        <button onClick={() => setShowForm(true)} className="btn-primary">
          <Plus className="h-4 w-4" />
          Request Blood
        </button>
      </div>

      <div className="space-y-3">
        {sorted.length === 0 ? (
          <div className="py-16 text-center">
            <AlertCircle className="mx-auto mb-3 h-10 w-10 text-gray-300" />
            <p className="text-sm text-gray-400">No blood requests at this time.</p>
          </div>
        ) : (
          sorted.map((r) => {
            const hospital = hospitals.find((h) => h.id === r.hospital_id);
            return (
              <div key={r.id} className="card p-4">
                <div className="flex flex-wrap items-start gap-4">
                  <div
                    className={`flex h-14 w-14 shrink-0 items-center justify-center rounded-2xl text-base font-bold ${
                      r.urgency === 'Critical'
                        ? 'bg-error-100 text-error-700'
                        : r.urgency === 'Urgent'
                          ? 'bg-warning-100 text-warning-700'
                          : 'bg-primary-100 text-primary-700'
                    }`}
                  >
                    {r.blood_group}
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <p className="text-sm font-semibold text-gray-900">{r.patient_name}</p>
                      <span
                        className={`badge ${
                          r.urgency === 'Critical'
                            ? 'bg-error-50 text-error-600'
                            : r.urgency === 'Urgent'
                              ? 'bg-warning-50 text-warning-600'
                              : 'bg-primary-50 text-primary-600'
                        }`}
                      >
                        {r.urgency}
                      </span>
                      <span
                        className={`badge ${
                          r.status === 'Open'
                            ? 'bg-success-50 text-success-600'
                            : r.status === 'Fulfilled'
                              ? 'bg-gray-100 text-gray-500'
                              : 'bg-error-50 text-error-600'
                        }`}
                      >
                        {r.status}
                      </span>
                    </div>
                    <div className="mt-1.5 flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-gray-500">
                      <span className="flex items-center gap-1">
                        <Droplet className="h-3 w-3" /> {r.units_needed} units needed
                      </span>
                      <span className="flex items-center gap-1">
                        <MapPin className="h-3 w-3" /> {r.city}
                      </span>
                      {hospital && (
                        <span className="flex items-center gap-1">
                          <Building2 className="h-3 w-3" /> {hospital.name}
                        </span>
                      )}
                      <span className="flex items-center gap-1">
                        <Clock className="h-3 w-3" /> {timeAgo(r.created_at)}
                      </span>
                    </div>
                    <div className="mt-2 text-xs text-gray-400">
                      Requested by {r.requester_name} · {r.requester_phone}
                    </div>
                  </div>
                  {r.status === 'Open' && (
                    <a href={`tel:${r.requester_phone}`} className="btn-secondary text-xs">
                      <Phone className="h-3.5 w-3.5" /> Contact
                    </a>
                  )}
                </div>
              </div>
            );
          })
        )}
      </div>

      {showForm && (
        <RequestFormModal
          city={city}
          hospitals={hospitals}
          onClose={() => setShowForm(false)}
          onSaved={() => { setShowForm(false); onRefresh(); }}
        />
      )}
    </div>
  );
}

function RequestFormModal({
  city,
  hospitals,
  onClose,
  onSaved,
}: {
  city: string;
  hospitals: Hospital[];
  onClose: () => void;
  onSaved: () => void;
}) {
  const [form, setForm] = useState({
    patient_name: '',
    blood_group: 'O+' as BloodGroup,
    units_needed: 1,
    requester_name: '',
    requester_phone: '',
    urgency: 'Normal' as 'Critical' | 'Urgent' | 'Normal',
    hospital_id: '',
  });
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.patient_name.trim() || !form.requester_name.trim() || !form.requester_phone.trim()) {
      setError('Patient name, requester name, and phone are required.');
      return;
    }
    setSaving(true);
    setError(null);
    const { error: insertError } = await db.from('blood_requests').insert({
      patient_name: form.patient_name.trim(),
      blood_group: form.blood_group,
      units_needed: form.units_needed,
      city,
      requester_name: form.requester_name.trim(),
      requester_phone: form.requester_phone.trim(),
      urgency: form.urgency,
      hospital_id: form.hospital_id || null,
      status: 'Open',
    });
    setSaving(false);
    if (insertError) {
      setError('Failed to create request. Please try again.');
      return;
    }
    onSaved();
  };

  return (
    <Modal onClose={onClose} title="Request Blood">
      <form onSubmit={handleSubmit} className="space-y-4">
        {error && <div className="rounded-lg bg-error-50 px-4 py-2 text-sm text-error-600">{error}</div>}
        <div>
          <label className="label">Patient Name *</label>
          <input className="input" value={form.patient_name} onChange={(e) => setForm({ ...form, patient_name: e.target.value })} placeholder="Patient name" />
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="label">Blood Group *</label>
            <select className="input" value={form.blood_group} onChange={(e) => setForm({ ...form, blood_group: e.target.value as BloodGroup })}>
              {BLOOD_GROUPS.map((g) => (
                <option key={g} value={g}>{g}</option>
              ))}
            </select>
          </div>
          <div>
            <label className="label">Units Needed *</label>
            <input type="number" min={1} max={20} className="input" value={form.units_needed} onChange={(e) => setForm({ ...form, units_needed: parseInt(e.target.value) || 1 })} />
          </div>
        </div>
        <div>
          <label className="label">Urgency *</label>
          <div className="grid grid-cols-3 gap-2">
            {(['Critical', 'Urgent', 'Normal'] as const).map((u) => (
              <button
                key={u}
                type="button"
                onClick={() => setForm({ ...form, urgency: u })}
                className={`rounded-xl px-3 py-2.5 text-sm font-medium transition-all ${
                  form.urgency === u
                    ? u === 'Critical'
                      ? 'bg-error-600 text-white'
                      : u === 'Urgent'
                        ? 'bg-warning-500 text-white'
                        : 'bg-primary-600 text-white'
                    : 'bg-gray-50 text-gray-600 hover:bg-gray-100'
                }`}
              >
                {u}
              </button>
            ))}
          </div>
        </div>
        <div>
          <label className="label">Hospital (optional)</label>
          <select className="input" value={form.hospital_id} onChange={(e) => setForm({ ...form, hospital_id: e.target.value })}>
            <option value="">No specific hospital</option>
            {hospitals.map((h) => (
              <option key={h.id} value={h.id}>{h.name}</option>
            ))}
          </select>
        </div>
        <div>
          <label className="label">Your Name *</label>
          <input className="input" value={form.requester_name} onChange={(e) => setForm({ ...form, requester_name: e.target.value })} placeholder="Your full name" />
        </div>
        <div>
          <label className="label">Your Phone *</label>
          <input className="input" value={form.requester_phone} onChange={(e) => setForm({ ...form, requester_phone: e.target.value })} placeholder="+1 234 567 890" />
        </div>
        <div className="flex gap-3 pt-2">
          <button type="button" onClick={onClose} className="btn-secondary flex-1">Cancel</button>
          <button type="submit" disabled={saving} className="btn-primary flex-1">
            {saving ? 'Submitting...' : 'Submit Request'}
          </button>
        </div>
      </form>
    </Modal>
  );
}

/* ============ Camps Tab ============ */

function CampsTab({ camps }: { camps: BloodCamp[] }) {
  const upcoming = camps.filter((c) => new Date(c.date) >= new Date(new Date().toDateString()));
  return (
    <div className="animate-fade-in space-y-5">
      <div>
        <h2 className="text-xl font-bold text-gray-900">Blood Donation Camps</h2>
        <p className="text-sm text-gray-500">{upcoming.length} upcoming camps</p>
      </div>
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {upcoming.length === 0 ? (
          <div className="col-span-full py-16 text-center">
            <Calendar className="mx-auto mb-3 h-10 w-10 text-gray-300" />
            <p className="text-sm text-gray-400">No upcoming donation camps scheduled.</p>
          </div>
        ) : (
          upcoming.map((c) => (
            <div key={c.id} className="card overflow-hidden">
              <div className="bg-gradient-to-br from-primary-500 to-primary-700 p-5">
                <div className="flex items-center justify-between text-white">
                  <Calendar className="h-6 w-6" />
                  <span className="text-sm font-semibold">
                    {new Date(c.date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
                  </span>
                </div>
                <h3 className="mt-3 text-lg font-bold text-white">{c.name}</h3>
              </div>
              <div className="p-5 space-y-2">
                <div className="flex items-start gap-2 text-sm text-gray-600">
                  <MapPin className="mt-0.5 h-4 w-4 shrink-0 text-gray-400" />
                  <span>{c.address}, {c.city}</span>
                </div>
                <div className="flex items-center gap-2 text-sm text-gray-600">
                  <Clock className="h-4 w-4 shrink-0 text-gray-400" />
                  <span>{c.start_time} – {c.end_time}</span>
                </div>
                {c.organizer && (
                  <div className="flex items-center gap-2 text-sm text-gray-600">
                    <Users className="h-4 w-4 shrink-0 text-gray-400" />
                    <span>{c.organizer}</span>
                  </div>
                )}
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}

/* ============ Shared ============ */

function Modal({ children, onClose, title }: { children: React.ReactNode; onClose: () => void; title: string }) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 animate-fade-in">
      <div className="absolute inset-0 bg-gray-900/40 backdrop-blur-sm" onClick={onClose} />
      <div className="relative z-10 w-full max-w-md rounded-3xl bg-white p-6 shadow-2xl animate-slide-up max-h-[90vh] overflow-y-auto">
        <div className="mb-5 flex items-center justify-between">
          <h3 className="text-lg font-bold text-gray-900">{title}</h3>
          <button onClick={onClose} className="rounded-lg p-1.5 text-gray-400 transition-colors hover:bg-gray-100 hover:text-gray-700">
            <X className="h-5 w-5" />
          </button>
        </div>
        {children}
      </div>
    </div>
  );
}

function timeAgo(dateStr: string): string {
  const diff = Date.now() - new Date(dateStr).getTime();
  const mins = Math.floor(diff / 60000);
  if (mins < 1) return 'just now';
  if (mins < 60) return `${mins}m ago`;
  const hours = Math.floor(mins / 60);
  if (hours < 24) return `${hours}h ago`;
  const days = Math.floor(hours / 24);
  return `${days}d ago`;
}
