export const BLOOD_GROUPS = [
  'A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'
] as const;

export type BloodGroup = (typeof BLOOD_GROUPS)[number];

export const BLOOD_COMPONENTS = [
  'Whole Blood', 'Plasma', 'Platelets', 'RBC'
] as const;

export type BloodComponent = (typeof BLOOD_COMPONENTS)[number];

export const URGENCY_LEVELS = [
  'Critical', 'Urgent', 'Normal'
] as const;

export type UrgencyLevel = (typeof URGENCY_LEVELS)[number];

export interface Hospital {
  id: string;
  name: string;
  address: string;
  city: string;
  latitude: number | null;
  longitude: number | null;
  phone: string | null;
  created_at: string;
}

export interface BloodCamp {
  id: string;
  name: string;
  address: string;
  city: string;
  latitude: number | null;
  longitude: number | null;
  date: string;
  start_time: string;
  end_time: string;
  organizer: string | null;
  hospital_id: string | null;
  created_at: string;
}

export interface BloodInventory {
  id: string;
  hospital_id: string;
  blood_group: BloodGroup;
  component: BloodComponent;
  units_available: number;
  units_needed: number;
  last_updated: string;
}

export interface Donor {
  id: string;
  name: string;
  blood_group: BloodGroup;
  city: string;
  phone: string;
  email: string | null;
  latitude: number | null;
  longitude: number | null;
  is_available: boolean;
  last_donated: string | null;
  hospital_id: string | null;
  created_at: string;
}

export interface BloodRequest {
  id: string;
  patient_name: string;
  blood_group: BloodGroup;
  units_needed: number;
  city: string;
  hospital_id: string | null;
  requester_name: string;
  requester_phone: string;
  urgency: UrgencyLevel;
  status: 'Open' | 'Fulfilled' | 'Cancelled';
  fulfilled_at: string | null;
  created_at: string;
}

export const demoHospitals: Hospital[] = [
  {
    id: 'h1',
    name: 'Apollo Hospital',
    address: 'Jubilee Hills',
    city: 'Hyderabad',
    latitude: 17.4326,
    longitude: 78.4071,
    phone: '+91 40 2360 7777',
    created_at: new Date().toISOString(),
  },
  {
    id: 'h2',
    name: 'CARE Hospitals',
    address: 'Banjara Hills',
    city: 'Hyderabad',
    latitude: 17.4156,
    longitude: 78.4347,
    phone: '+91 40 6165 6565',
    created_at: new Date().toISOString(),
  },
  {
    id: 'h3',
    name: 'KIMS Hospital',
    address: 'Secunderabad',
    city: 'Hyderabad',
    latitude: 17.4399,
    longitude: 78.4983,
    phone: '+91 40 4488 5000',
    created_at: new Date().toISOString(),
  },
];

export const demoDonors: Donor[] = [
  {
    id: 'd1',
    name: 'Rahul Sharma',
    blood_group: 'O+',
    city: 'Hyderabad',
    phone: '9876543210',
    email: 'rahul@example.com',
    latitude: 17.4239,
    longitude: 78.4738,
    is_available: true,
    last_donated: null,
    hospital_id: 'h1',
    created_at: new Date().toISOString(),
  },
  {
    id: 'd2',
    name: 'Priya Reddy',
    blood_group: 'A+',
    city: 'Hyderabad',
    phone: '9876543211',
    email: 'priya@example.com',
    latitude: 17.4156,
    longitude: 78.4347,
    is_available: true,
    last_donated: null,
    hospital_id: 'h2',
    created_at: new Date().toISOString(),
  },
  {
    id: 'd3',
    name: 'Arjun Kumar',
    blood_group: 'B+',
    city: 'Hyderabad',
    phone: '9876543212',
    email: 'arjun@example.com',
    latitude: 17.4399,
    longitude: 78.4983,
    is_available: true,
    last_donated: null,
    hospital_id: 'h3',
    created_at: new Date().toISOString(),
  },
];

export const demoInventory: BloodInventory[] = [
  {
    id: 'i1',
    hospital_id: 'h1',
    blood_group: 'O+',
    component: 'Whole Blood',
    units_available: 12,
    units_needed: 8,
    last_updated: new Date().toISOString(),
  },
  {
    id: 'i2',
    hospital_id: 'h1',
    blood_group: 'A+',
    component: 'Whole Blood',
    units_available: 7,
    units_needed: 10,
    last_updated: new Date().toISOString(),
  },
  {
    id: 'i3',
    hospital_id: 'h2',
    blood_group: 'B+',
    component: 'Whole Blood',
    units_available: 5,
    units_needed: 6,
    last_updated: new Date().toISOString(),
  },
  {
    id: 'i4',
    hospital_id: 'h3',
    blood_group: 'AB+',
    component: 'Plasma',
    units_available: 9,
    units_needed: 4,
    last_updated: new Date().toISOString(),
  },
];

export const demoRequests: BloodRequest[] = [
  {
    id: 'r1',
    patient_name: 'Amit Verma',
    blood_group: 'O+',
    units_needed: 2,
    city: 'Hyderabad',
    hospital_id: 'h1',
    requester_name: 'Neha Verma',
    requester_phone: '9876543220',
    urgency: 'Urgent',
    status: 'Open',
    fulfilled_at: null,
    created_at: new Date().toISOString(),
  },
  {
    id: 'r2',
    patient_name: 'Sneha Rao',
    blood_group: 'A+',
    units_needed: 1,
    city: 'Hyderabad',
    hospital_id: 'h2',
    requester_name: 'Vikram Rao',
    requester_phone: '9876543221',
    urgency: 'Critical',
    status: 'Open',
    fulfilled_at: null,
    created_at: new Date().toISOString(),
  },
];

export const demoCamps: BloodCamp[] = [
  {
    id: 'c1',
    name: 'Community Blood Donation Camp',
    address: 'Jubilee Hills',
    city: 'Hyderabad',
    latitude: 17.4326,
    longitude: 78.4071,
    date: '2026-09-15',
    start_time: '09:00',
    end_time: '16:00',
    organizer: 'LifeFlow',
    hospital_id: 'h1',
    created_at: new Date().toISOString(),
  },
  {
    id: 'c2',
    name: 'Emergency Blood Drive',
    address: 'Banjara Hills',
    city: 'Hyderabad',
    latitude: 17.4156,
    longitude: 78.4347,
    date: '2026-09-20',
    start_time: '10:00',
    end_time: '15:00',
    organizer: 'LifeFlow',
    hospital_id: 'h2',
    created_at: new Date().toISOString(),
  },
];