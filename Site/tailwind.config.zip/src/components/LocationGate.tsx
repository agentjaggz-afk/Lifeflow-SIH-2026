import { useState, useEffect } from 'react';
import { MapPin, Navigation, Search, Building2, Droplet, Heart, Activity, Users, ShieldCheck } from 'lucide-react';
import { db, type Hospital } from '@/lib/data';

interface LocationGateProps {
  onLocationSet: (city: string, coords: { lat: number; lng: number } | null) => void;
  onSelectHospital: (hospital: Hospital) => void;
}

const POPULAR_CITIES = [
  'New York',
  'Los Angeles',
  'Chicago',
  'Houston',
  'Phoenix',
  'Philadelphia',
  'San Antonio',
  'San Diego',
];

export function LocationGate({ onLocationSet, onSelectHospital }: LocationGateProps) {
  const [manualCity, setManualCity] = useState('');
  const [detecting, setDetecting] = useState(false);
  const [gpsError, setGpsError] = useState<string | null>(null);
  const [hospitals, setHospitals] = useState<Hospital[]>([]);
  const [showHospitalList, setShowHospitalList] = useState(false);

  useEffect(() => {
    db.from('hospitals').select('*').order('name').then(({ data }) => {
      if (data) setHospitals(data as Hospital[]);
    });
  }, []);

  const handleGPS = () => {
    setDetecting(true);
    setGpsError(null);
    if (!navigator.geolocation) {
      setGpsError('Geolocation is not supported by your browser.');
      setDetecting(false);
      return;
    }
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        const { latitude, longitude } = pos.coords;
        setDetecting(false);
        onLocationSet('Your Location', { lat: latitude, lng: longitude });
      },
      (err) => {
        setDetecting(false);
        setGpsError(
          err.code === 1
            ? 'Location access denied. Please enter your city manually.'
            : 'Unable to detect location. Please enter your city manually.',
        );
      },
      { enableHighAccuracy: true, timeout: 10000 },
    );
  };

  const handleManual = () => {
    if (manualCity.trim()) {
      onLocationSet(manualCity.trim(), null);
    }
  };

  return (
    <div className="min-h-screen relative overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 bg-gradient-to-br from-primary-700 via-primary-800 to-primary-950" />
      <div className="absolute inset-0 opacity-20"
        style={{
          backgroundImage: 'radial-gradient(circle at 20% 50%, rgba(255,255,255,0.15) 0%, transparent 50%), radial-gradient(circle at 80% 20%, rgba(255,255,255,0.1) 0%, transparent 40%), radial-gradient(circle at 60% 80%, rgba(255,255,255,0.08) 0%, transparent 40%)',
        }}
      />

      {/* Content */}
      <div className="relative z-10 flex min-h-screen flex-col">
        {/* Header */}
        <header className="flex items-center justify-between px-6 py-5 md:px-12">
          <div className="flex items-center gap-3">
            <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-white/10 backdrop-blur-sm ring-1 ring-white/20">
              <Droplet className="h-6 w-6 text-white" fill="white" />
            </div>
            <div>
              <h1 className="text-lg font-bold text-white tracking-tight">LifeFlow</h1>
              <p className="text-xs text-white/60">Blood Network Platform</p>
            </div>
          </div>
          <div className="hidden items-center gap-2 rounded-full bg-white/10 px-4 py-2 backdrop-blur-sm ring-1 ring-white/20 md:flex">
            <ShieldCheck className="h-4 w-4 text-white/80" />
            <span className="text-xs font-medium text-white/80">Real-time Network</span>
          </div>
        </header>

        {/* Hero */}
        <div className="flex flex-1 flex-col items-center justify-center px-6 py-12">
          <div className="w-full max-w-2xl animate-fade-in text-center">
            <div className="mb-6 inline-flex items-center gap-2 rounded-full bg-white/10 px-4 py-1.5 backdrop-blur-sm ring-1 ring-white/20">
              <Activity className="h-3.5 w-3.5 text-white/80" />
              <span className="text-xs font-medium text-white/80">Live blood metrics in your area</span>
            </div>
            <h2 className="mb-4 text-4xl font-bold leading-tight text-white md:text-5xl md:leading-tight">
              Connecting donors, receivers,<br />hospitals &amp; blood camps
            </h2>
            <p className="mb-10 text-base text-white/70 md:text-lg">
              Real-time blood availability across every blood group and component.
              Find donors, track inventory, and save lives — all in one network.
            </p>

            {/* Location card */}
            <div className="rounded-3xl bg-white p-6 shadow-2xl md:p-8 animate-slide-up">
              <div className="mb-5">
                <h3 className="mb-1 text-xl font-bold text-gray-900">Where are you?</h3>
                <p className="text-sm text-gray-500">Set your location to see real-time blood data near you.</p>
              </div>

              {/* GPS button */}
              <button
                onClick={handleGPS}
                disabled={detecting}
                className="mb-4 flex w-full items-center justify-center gap-3 rounded-xl bg-primary-50 px-6 py-4 text-sm font-semibold text-primary-700 ring-1 ring-primary-100 transition-all hover:bg-primary-100 hover:ring-primary-200 active:scale-[0.98] disabled:opacity-60"
              >
                <Navigation className={`h-5 w-5 ${detecting ? 'animate-spin' : ''}`} />
                {detecting ? 'Detecting your location...' : 'Use my current location (GPS)'}
              </button>

              {gpsError && (
                <p className="mb-4 rounded-lg bg-error-50 px-4 py-2 text-sm text-error-600">{gpsError}</p>
              )}

              {/* Divider */}
              <div className="my-5 flex items-center gap-3">
                <div className="h-px flex-1 bg-gray-100" />
                <span className="text-xs font-medium text-gray-400">OR</span>
                <div className="h-px flex-1 bg-gray-100" />
              </div>

              {/* Manual input */}
              <div className="flex gap-2">
                <div className="relative flex-1">
                  <MapPin className="absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-400" />
                  <input
                    type="text"
                    value={manualCity}
                    onChange={(e) => setManualCity(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && handleManual()}
                    placeholder="Enter your city..."
                    className="w-full rounded-xl border border-gray-200 bg-gray-50 py-3.5 pl-10 pr-4 text-sm text-gray-900 placeholder-gray-400 transition-all focus:border-primary-400 focus:bg-white focus:outline-none focus:ring-2 focus:ring-primary-100"
                  />
                </div>
                <button onClick={handleManual} disabled={!manualCity.trim()} className="btn-primary">
                  <Search className="h-4 w-4" />
                </button>
              </div>

              {/* Popular cities */}
              <div className="mt-5">
                <p className="mb-2 text-xs font-medium text-gray-400">Popular cities</p>
                <div className="flex flex-wrap gap-2">
                  {POPULAR_CITIES.map((c) => (
                    <button
                      key={c}
                      onClick={() => onLocationSet(c, null)}
                      className="rounded-full bg-gray-50 px-3.5 py-1.5 text-xs font-medium text-gray-600 ring-1 ring-gray-100 transition-all hover:bg-primary-50 hover:text-primary-700 hover:ring-primary-200"
                    >
                      {c}
                    </button>
                  ))}
                </div>
              </div>

              {/* Hospital quick access */}
              {hospitals.length > 0 && (
                <div className="mt-6 border-t border-gray-100 pt-5">
                  <button
                    onClick={() => setShowHospitalList(!showHospitalList)}
                    className="flex w-full items-center justify-between text-left"
                  >
                    <span className="flex items-center gap-2 text-sm font-semibold text-gray-700">
                      <Building2 className="h-4 w-4 text-primary-600" />
                      Hospital Management Portal
                    </span>
                    <span className="text-xs text-gray-400">{showHospitalList ? 'Hide' : 'Select hospital →'}</span>
                  </button>
                  {showHospitalList && (
                    <div className="mt-3 grid gap-2 animate-fade-in">
                      {hospitals.map((h) => (
                        <button
                          key={h.id}
                          onClick={() => onSelectHospital(h)}
                          className="flex items-center justify-between rounded-xl bg-gray-50 px-4 py-3 text-left transition-all hover:bg-primary-50 hover:ring-1 hover:ring-primary-200"
                        >
                          <div>
                            <p className="text-sm font-semibold text-gray-900">{h.name}</p>
                            <p className="text-xs text-gray-500">{h.address}, {h.city}</p>
                          </div>
                          <Building2 className="h-4 w-4 text-gray-300" />
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              )}
            </div>

            {/* Stats */}
            <div className="mt-10 grid grid-cols-3 gap-4">
              {[
                { icon: Users, label: 'Donors', value: 'Network' },
                { icon: Building2, label: 'Hospitals', value: `${hospitals.length}+` },
                { icon: Heart, label: 'Lives Saved', value: 'Real-time' },
              ].map((s) => (
                <div key={s.label} className="rounded-2xl bg-white/5 p-4 backdrop-blur-sm ring-1 ring-white/10">
                  <s.icon className="mx-auto mb-2 h-5 w-5 text-white/70" />
                  <p className="text-sm font-semibold text-white">{s.value}</p>
                  <p className="text-xs text-white/50">{s.label}</p>
                </div>
              ))}
            </div>
          </div>
        </div>

        <footer className="px-6 py-5 text-center md:px-12">
          <p className="text-xs text-white/40">LifeFlow — Every drop counts. Every donor matters.</p>
        </footer>
      </div>
    </div>
  );
}
