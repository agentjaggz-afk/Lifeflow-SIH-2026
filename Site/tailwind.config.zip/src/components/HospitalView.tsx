import { useState, useEffect, useCallback } from 'react';
import {
  ArrowLeft, Droplet, Building2, Plus, Minus, Save, CheckCircle2,
  AlertCircle, Clock, Phone, MapPin, Users, Activity, Trash2, X,
  Calendar, Search,
} from 'lucide-react';
import {
  db,
  BLOOD_GROUPS,
  BLOOD_COMPONENTS,
  type BloodGroup,
  type BloodComponent,
  type BloodInventory,
  type BloodRequest,
  type BloodCamp,
  type Hospital,
} from '@/lib/data';

interface HospitalViewProps {
  hospital: Hospital;
  city: string;
  onBack: () => void;
}

type Tab = 'inventory' | 'requests' | 'camps';

export function HospitalView({ hospital, city, onBack }: HospitalViewProps) {
  const [tab, setTab] = useState<Tab>('inventory');
  const [inventory, setInventory] = useState<BloodInventory[]>([]);
  const [requests, setRequests] = useState<BloodRequest[]>([]);
  const [camps, setCamps] = useState<BloodCamp[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchData = useCallback(async () => {
    setLoading(true);
    const [invRes, reqRes, campRes] = await Promise.all([
      db.from('blood_inventory').select('*').eq('hospital_id', hospital.id).order('blood_group'),
      db.from('blood_requests').select('*').eq('hospital_id', hospital.id).order('created_at', { ascending: false }),
      db.from('blood_camps').select('*').eq('hospital_id', hospital.id).order('date', { ascending: true }),
    ]);
    setInventory((invRes.data as BloodInventory[]) || []);
    setRequests((reqRes.data as BloodRequest[]) || []);
    setCamps((campRes.data as BloodCamp[]) || []);
    setLoading(false);
  }, [hospital.id]);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  useEffect(() => {
    const invChannel = db
      .channel('hosp-inventory-changes')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'blood_inventory' }, () => fetchData())
      .subscribe();
    const reqChannel = db
      .channel('hosp-request-changes')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'blood_requests' }, () => fetchData())
      .subscribe();
    const campChannel = db
      .channel('hosp-camp-changes')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'blood_camps' }, () => fetchData())
      .subscribe();
    return () => {
      db.removeChannel(invChannel);
      db.removeChannel(reqChannel);
      db.removeChannel(campChannel);
    };
  }, [fetchData]);

  return (
    <div className="min-h-screen bg-[#fdf6f3]">
      {/* Header */}
      <header className="sticky top-0 z-30 border-b border-gray-100 bg-white/80 backdrop-blur-lg">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-3 md:px-6">
          <div className="flex items-center gap-3">
            <button onClick={onBack} className="btn-ghost">
              <ArrowLeft className="h-4 w-4" />
              <span className="hidden sm:inline">Back</span>
            </button>
            <div className="flex items-center gap-2 rounded-full bg-primary-50 px-3 py-1.5 ring-1 ring-primary-100">
              <Building2 className="h-3.5 w-3.5 text-primary-600" />
              <span className="text-sm font-semibold text-primary-700">{hospital.name}</span>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-primary-600">
              <Droplet className="h-5 w-5 text-white" fill="white" />
            </div>
            <span className="text-lg font-bold text-gray-900">LifeFlow</span>
          </div>
        </div>
        {/* Tabs */}
        <div className="mx-auto max-w-7xl px-4 md:px-6">
          <nav className="flex gap-1 overflow-x-auto pb-px">
            {[
              { id: 'inventory' as Tab, label: 'Blood Inventory', icon: Droplet },
              { id: 'requests' as Tab, label: 'Incoming Requests', icon: AlertCircle },
              { id: 'camps' as Tab, label: 'Donation Camps', icon: Calendar },
            ].map((t) => (
              <button
                key={t.id}
                onClick={() => setTab(t.id)}
                className={`flex items-center gap-2 border-b-2 px-4 py-2.5 text-sm font-medium transition-colors ${
                  tab === t.id
                    ? 'border-primary-600 text-primary-700'
                    : 'border-transparent text-gray-500 hover:text-gray-800'
                }`}
              >
                <t.icon className="h-4 w-4" />
                {t.label}
                {t.id === 'requests' && requests.filter((r) => r.status === 'Open').length > 0 && (
                  <span className="ml-1 rounded-full bg-error-100 px-1.5 py-0.5 text-xs font-bold text-error-600">
                    {requests.filter((r) => r.status === 'Open').length}
                  </span>
                )}
              </button>
            ))}
          </nav>
        </div>
      </header>

      <main className="mx-auto max-w-7xl px-4 py-6 md:px-6">
        {loading ? (
          <div className="flex h-64 items-center justify-center">
            <div className="flex flex-col items-center gap-3">
              <div className="h-8 w-8 animate-spin rounded-full border-2 border-primary-200 border-t-primary-600" />
              <p className="text-sm text-gray-500">Loading hospital data...</p>
            </div>
          </div>
        ) : (
          <>
            {tab === 'inventory' && <InventoryTab inventory={inventory} hospitalId={hospital.id} onRefresh={fetchData} />}
            {tab === 'requests' && <RequestsTab requests={requests} onRefresh={fetchData} />}
            {tab === 'camps' && <CampsTab camps={camps} hospital={hospital} city={city} onRefresh={fetchData} />}
          </>
        )}
      </main>
    </div>
  );
}

/* ============ Inventory Tab ============ */

function InventoryTab({ inventory, hospitalId, onRefresh }: { inventory: BloodInventory[]; hospitalId: string; onRefresh: () => void }) {
  const [showForm, setShowForm] = useState(false);
  const [search, setSearch] = useState('');
  const [filterGroup, setFilterGroup] = useState<BloodGroup | 'all'>('all');

  const filtered = inventory.filter((i) => {
    const matchSearch =
      i.blood_group.toLowerCase().includes(search.toLowerCase()) ||
      i.component.toLowerCase().includes(search.toLowerCase());
    const matchGroup = filterGroup === 'all' || i.blood_group === filterGroup;
    return matchSearch && matchGroup;
  });

  const updateUnits = async (id: string, field: 'units_available' | 'units_needed', delta: number) => {
    const item = inventory.find((i) => i.id === id);
    if (!item) return;
    const newVal = Math.max(0, item[field] + delta);
    await db
      .from('blood_inventory')
      .update({ [field]: newVal, last_updated: new Date().toISOString() })
      .eq('id', id);
    onRefresh();
  };

  const setUnits = async (id: string, field: 'units_available' | 'units_needed', value: number) => {
    await db
      .from('blood_inventory')
      .update({ [field]: Math.max(0, value), last_updated: new Date().toISOString() })
      .eq('id', id);
    onRefresh();
  };

  const totalAvailable = inventory.reduce((s, i) => s + i.units_available, 0);
  const totalNeeded = inventory.reduce((s, i) => s + i.units_needed, 0);

  return (
    <div className="animate-fade-in space-y-5">
      {/* Summary */}
      <div className="grid grid-cols-2 gap-4 md:grid-cols-4">
        <div className="card p-4">
          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-success-50">
            <Droplet className="h-5 w-5 text-success-600" />
          </div>
          <p className="mt-3 text-2xl font-bold text-gray-900">{totalAvailable}</p>
          <p className="text-xs text-gray-500">Total Units Available</p>
        </div>
        <div className="card p-4">
          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-warning-50">
            <AlertCircle className="h-5 w-5 text-warning-600" />
          </div>
          <p className="mt-3 text-2xl font-bold text-gray-900">{totalNeeded}</p>
          <p className="text-xs text-gray-500">Total Units Needed</p>
        </div>
        <div className="card p-4">
          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-primary-50">
            <Activity className="h-5 w-5 text-primary-600" />
          </div>
          <p className="mt-3 text-2xl font-bold text-gray-900">{inventory.length}</p>
          <p className="text-xs text-gray-500">Inventory Entries</p>
        </div>
        <div className="card p-4">
          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-error-50">
            <AlertCircle className="h-5 w-5 text-error-600" />
          </div>
          <p className="mt-3 text-2xl font-bold text-gray-900">
            {inventory.filter((i) => i.units_available === 0).length}
          </p>
          <p className="text-xs text-gray-500">Out of Stock Groups</p>
        </div>
      </div>

      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h2 className="text-xl font-bold text-gray-900">Blood Inventory Management</h2>
          <p className="text-sm text-gray-500">Adjust stock levels in real-time</p>
        </div>
        <button onClick={() => setShowForm(true)} className="btn-primary">
          <Plus className="h-4 w-4" />
          Add Inventory Entry
        </button>
      </div>

      {/* Filters */}
      <div className="flex flex-wrap items-center gap-3">
        <div className="relative flex-1 min-w-[200px]">
          <Search className="absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-400" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search by blood group or component..."
            className="input pl-10"
          />
        </div>
        <select
          value={filterGroup}
          onChange={(e) => setFilterGroup(e.target.value as BloodGroup | 'all')}
          className="input w-auto min-w-[140px]"
        >
          <option value="all">All Groups</option>
          {BLOOD_GROUPS.map((g) => (
            <option key={g} value={g}>{g}</option>
          ))}
        </select>
      </div>

      {/* Inventory table */}
      <div className="card overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-gray-100 bg-gray-50/50 text-left text-xs font-semibold uppercase tracking-wide text-gray-500">
                <th className="px-4 py-3">Blood Group</th>
                <th className="px-4 py-3">Component</th>
                <th className="px-4 py-3">Available</th>
                <th className="px-4 py-3">Needed</th>
                <th className="px-4 py-3">Status</th>
                <th className="px-4 py-3 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-50">
              {filtered.length === 0 ? (
                <tr>
                  <td colSpan={6} className="px-4 py-12 text-center text-sm text-gray-400">
                    No inventory entries. Click "Add Inventory Entry" to get started.
                  </td>
                </tr>
              ) : (
                filtered.map((item) => {
                  const status = item.units_available === 0
                    ? { label: 'Out of Stock', class: 'bg-error-50 text-error-600' }
                    : item.units_available < 10
                      ? { label: 'Low Stock', class: 'bg-warning-50 text-warning-600' }
                      : { label: 'In Stock', class: 'bg-success-50 text-success-600' };
                  return (
                    <tr key={item.id} className="transition-colors hover:bg-gray-50/50">
                      <td className="px-4 py-3">
                        <span className="flex h-9 w-9 items-center justify-center rounded-lg bg-primary-100 text-sm font-bold text-primary-700">
                          {item.blood_group}
                        </span>
                      </td>
                      <td className="px-4 py-3 text-sm text-gray-700">{item.component}</td>
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-2">
                          <button
                            onClick={() => updateUnits(item.id, 'units_available', -1)}
                            className="flex h-7 w-7 items-center justify-center rounded-lg bg-gray-100 text-gray-600 transition-colors hover:bg-gray-200"
                          >
                            <Minus className="h-3.5 w-3.5" />
                          </button>
                          <input
                            type="number"
                            value={item.units_available}
                            onChange={(e) => setUnits(item.id, 'units_available', parseInt(e.target.value) || 0)}
                            className="w-14 rounded-lg border border-gray-200 px-2 py-1 text-center text-sm font-semibold text-gray-900 focus:border-primary-400 focus:outline-none focus:ring-1 focus:ring-primary-100"
                          />
                          <button
                            onClick={() => updateUnits(item.id, 'units_available', 1)}
                            className="flex h-7 w-7 items-center justify-center rounded-lg bg-gray-100 text-gray-600 transition-colors hover:bg-gray-200"
                          >
                            <Plus className="h-3.5 w-3.5" />
                          </button>
                        </div>
                      </td>
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-2">
                          <button
                            onClick={() => updateUnits(item.id, 'units_needed', -1)}
                            className="flex h-7 w-7 items-center justify-center rounded-lg bg-gray-100 text-gray-600 transition-colors hover:bg-gray-200"
                          >
                            <Minus className="h-3.5 w-3.5" />
                          </button>
                          <input
                            type="number"
                            value={item.units_needed}
                            onChange={(e) => setUnits(item.id, 'units_needed', parseInt(e.target.value) || 0)}
                            className="w-14 rounded-lg border border-gray-200 px-2 py-1 text-center text-sm font-semibold text-gray-900 focus:border-primary-400 focus:outline-none focus:ring-1 focus:ring-primary-100"
                          />
                          <button
                            onClick={() => updateUnits(item.id, 'units_needed', 1)}
                            className="flex h-7 w-7 items-center justify-center rounded-lg bg-gray-100 text-gray-600 transition-colors hover:bg-gray-200"
                          >
                            <Plus className="h-3.5 w-3.5" />
                          </button>
                        </div>
                      </td>
                      <td className="px-4 py-3">
                        <span className={`badge ${status.class}`}>{status.label}</span>
                      </td>
                      <td className="px-4 py-3 text-right">
                        <button
                          onClick={async () => {
                            await db.from('blood_inventory').delete().eq('id', item.id);
                            onRefresh();
                          }}
                          className="rounded-lg p-1.5 text-gray-400 transition-colors hover:bg-error-50 hover:text-error-600"
                        >
                          <Trash2 className="h-4 w-4" />
                        </button>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {showForm && (
        <InventoryFormModal
          hospitalId={hospitalId}
          existing={inventory}
          onClose={() => setShowForm(false)}
          onSaved={() => { setShowForm(false); onRefresh(); }}
        />
      )}
    </div>
  );
}

function InventoryFormModal({
  hospitalId,
  existing,
  onClose,
  onSaved,
}: {
  hospitalId: string;
  existing: BloodInventory[];
  onClose: () => void;
  onSaved: () => void;
}) {
  const [form, setForm] = useState({
    blood_group: 'O+' as BloodGroup,
    component: 'Whole Blood' as BloodComponent,
    units_available: 0,
    units_needed: 0,
  });
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    setError(null);
    const { error: insertError } = await db.from('blood_inventory').insert({
      hospital_id: hospitalId,
      blood_group: form.blood_group,
      component: form.component,
      units_available: form.units_available,
      units_needed: form.units_needed,
    });
    setSaving(false);
    if (insertError) {
      setError('Failed to add entry. This blood group + component may already exist.');
      return;
    }
    onSaved();
  };

  return (
    <Modal onClose={onClose} title="Add Inventory Entry">
      <form onSubmit={handleSubmit} className="space-y-4">
        {error && <div className="rounded-lg bg-error-50 px-4 py-2 text-sm text-error-600">{error}</div>}
        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="label">Blood Group *</label>
            <select className="input" value={form.blood_group} onChange={(e) => setForm({ ...form, blood_group: e.target.value as BloodGroup })}>
              {BLOOD_GROUPS.map((g) => (
                <option key={g} value={g}>{g}</option>
              ))}
            </select>
          </div>
          <div>
            <label className="label">Component *</label>
            <select className="input" value={form.component} onChange={(e) => setForm({ ...form, component: e.target.value as BloodComponent })}>
              {BLOOD_COMPONENTS.map((c) => (
                <option key={c} value={c}>{c}</option>
              ))}
            </select>
          </div>
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="label">Units Available</label>
            <input type="number" min={0} className="input" value={form.units_available} onChange={(e) => setForm({ ...form, units_available: parseInt(e.target.value) || 0 })} />
          </div>
          <div>
            <label className="label">Units Needed</label>
            <input type="number" min={0} className="input" value={form.units_needed} onChange={(e) => setForm({ ...form, units_needed: parseInt(e.target.value) || 0 })} />
          </div>
        </div>
        <div className="flex gap-3 pt-2">
          <button type="button" onClick={onClose} className="btn-secondary flex-1">Cancel</button>
          <button type="submit" disabled={saving} className="btn-primary flex-1">
            {saving ? 'Saving...' : 'Add Entry'}
          </button>
        </div>
      </form>
    </Modal>
  );
}

/* ============ Requests Tab ============ */

function RequestsTab({ requests, onRefresh }: { requests: BloodRequest[]; onRefresh: () => void }) {
  const [filter, setFilter] = useState<'all' | 'Open' | 'Fulfilled' | 'Cancelled'>('all');
  const filtered = filter === 'all' ? requests : requests.filter((r) => r.status === filter);

  const updateStatus = async (id: string, status: 'Fulfilled' | 'Cancelled') => {
    const update: Record<string, unknown> = { status };
    if (status === 'Fulfilled') update.fulfilled_at = new Date().toISOString();
    await db.from('blood_requests').update(update).eq('id', id);
    onRefresh();
  };

  const sorted = [...filtered].sort((a, b) => {
    const urgencyOrder = { Critical: 0, Urgent: 1, Normal: 2 };
    if (a.status !== b.status) {
      const statusOrder = { Open: 0, Fulfilled: 1, Cancelled: 2 };
      return statusOrder[a.status] - statusOrder[b.status];
    }
    return urgencyOrder[a.urgency] - urgencyOrder[b.urgency];
  });

  return (
    <div className="animate-fade-in space-y-5">
      <div>
        <h2 className="text-xl font-bold text-gray-900">Incoming Blood Requests</h2>
        <p className="text-sm text-gray-500">Manage requests directed to your hospital</p>
      </div>

      {/* Filter tabs */}
      <div className="flex gap-2">
        {(['all', 'Open', 'Fulfilled', 'Cancelled'] as const).map((f) => (
          <button
            key={f}
            onClick={() => setFilter(f)}
            className={`rounded-full px-4 py-1.5 text-sm font-medium transition-colors ${
              filter === f ? 'bg-primary-600 text-white' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
            }`}
          >
            {f === 'all' ? 'All' : f}
            {f !== 'all' && (
              <span className="ml-1.5 text-xs opacity-70">
                {requests.filter((r) => r.status === f).length}
              </span>
            )}
          </button>
        ))}
      </div>

      <div className="space-y-3">
        {sorted.length === 0 ? (
          <div className="py-16 text-center">
            <AlertCircle className="mx-auto mb-3 h-10 w-10 text-gray-300" />
            <p className="text-sm text-gray-400">No requests to display.</p>
          </div>
        ) : (
          sorted.map((r) => (
            <div key={r.id} className="card p-4">
              <div className="flex flex-wrap items-start gap-4">
                <div
                  className={`flex h-14 w-14 shrink-0 items-center justify-center rounded-2xl text-base font-bold ${
                    r.urgency === 'Critical'
                      ? 'bg-error-100 text-error-700'
                      : r.urgency === 'Urgent'
                        ? 'bg-warning-100 text-warning-700'
                        : 'bg-primary-100 text-primary-700'
                  }`}
                >
                  {r.blood_group}
                </div>
                <div className="min-w-0 flex-1">
                  <div className="flex flex-wrap items-center gap-2">
                    <p className="text-sm font-semibold text-gray-900">{r.patient_name}</p>
                    <span className={`badge ${
                      r.urgency === 'Critical' ? 'bg-error-50 text-error-600'
                        : r.urgency === 'Urgent' ? 'bg-warning-50 text-warning-600'
                        : 'bg-primary-50 text-primary-600'
                    }`}>{r.urgency}</span>
                    <span className={`badge ${
                      r.status === 'Open' ? 'bg-success-50 text-success-600'
                        : r.status === 'Fulfilled' ? 'bg-gray-100 text-gray-500'
                        : 'bg-error-50 text-error-600'
                    }`}>{r.status}</span>
                  </div>
                  <div className="mt-1.5 flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-gray-500">
                    <span className="flex items-center gap-1"><Droplet className="h-3 w-3" /> {r.units_needed} units</span>
                    <span className="flex items-center gap-1"><MapPin className="h-3 w-3" /> {r.city}</span>
                    <span className="flex items-center gap-1"><Clock className="h-3 w-3" /> {timeAgo(r.created_at)}</span>
                  </div>
                  <div className="mt-2 text-xs text-gray-400">
                    Requested by {r.requester_name} · {r.requester_phone}
                  </div>
                </div>
                {r.status === 'Open' && (
                  <div className="flex gap-2">
                    <a href={`tel:${r.requester_phone}`} className="btn-secondary text-xs">
                      <Phone className="h-3.5 w-3.5" /> Contact
                    </a>
                    <button
                      onClick={() => updateStatus(r.id, 'Fulfilled')}
                      className="inline-flex items-center gap-1.5 rounded-xl bg-success-600 px-3 py-2 text-xs font-semibold text-white transition-colors hover:bg-success-700"
                    >
                      <CheckCircle2 className="h-3.5 w-3.5" /> Fulfill
                    </button>
                    <button
                      onClick={() => updateStatus(r.id, 'Cancelled')}
                      className="inline-flex items-center gap-1.5 rounded-xl bg-gray-100 px-3 py-2 text-xs font-semibold text-gray-600 transition-colors hover:bg-gray-200"
                    >
                      <X className="h-3.5 w-3.5" /> Cancel
                    </button>
                  </div>
                )}
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}

/* ============ Camps Tab ============ */

function CampsTab({ camps, hospital, city, onRefresh }: { camps: BloodCamp[]; hospital: Hospital; city: string; onRefresh: () => void }) {
  const [showForm, setShowForm] = useState(false);

  return (
    <div className="animate-fade-in space-y-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h2 className="text-xl font-bold text-gray-900">Donation Camps</h2>
          <p className="text-sm text-gray-500">Camps organized by {hospital.name}</p>
        </div>
        <button onClick={() => setShowForm(true)} className="btn-primary">
          <Plus className="h-4 w-4" />
          Schedule Camp
        </button>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {camps.length === 0 ? (
          <div className="col-span-full py-16 text-center">
            <Calendar className="mx-auto mb-3 h-10 w-10 text-gray-300" />
            <p className="text-sm text-gray-400">No donation camps scheduled yet.</p>
          </div>
        ) : (
          camps.map((c) => (
            <div key={c.id} className="card overflow-hidden">
              <div className="bg-gradient-to-br from-primary-500 to-primary-700 p-5">
                <div className="flex items-center justify-between text-white">
                  <Calendar className="h-6 w-6" />
                  <span className="text-sm font-semibold">
                    {new Date(c.date).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}
                  </span>
                </div>
                <h3 className="mt-3 text-lg font-bold text-white">{c.name}</h3>
              </div>
              <div className="p-5 space-y-2">
                <div className="flex items-start gap-2 text-sm text-gray-600">
                  <MapPin className="mt-0.5 h-4 w-4 shrink-0 text-gray-400" />
                  <span>{c.address}, {c.city}</span>
                </div>
                <div className="flex items-center gap-2 text-sm text-gray-600">
                  <Clock className="h-4 w-4 shrink-0 text-gray-400" />
                  <span>{c.start_time} – {c.end_time}</span>
                </div>
                {c.organizer && (
                  <div className="flex items-center gap-2 text-sm text-gray-600">
                    <Users className="h-4 w-4 shrink-0 text-gray-400" />
                    <span>{c.organizer}</span>
                  </div>
                )}
                <button
                  onClick={async () => {
                    await db.from('blood_camps').delete().eq('id', c.id);
                    onRefresh();
                  }}
                  className="mt-2 flex w-full items-center justify-center gap-1.5 rounded-lg bg-gray-50 py-2 text-xs font-medium text-gray-500 transition-colors hover:bg-error-50 hover:text-error-600"
                >
                  <Trash2 className="h-3.5 w-3.5" /> Remove Camp
                </button>
              </div>
            </div>
          ))
        )}
      </div>

      {showForm && (
        <CampFormModal
          hospital={hospital}
          city={city}
          onClose={() => setShowForm(false)}
          onSaved={() => { setShowForm(false); onRefresh(); }}
        />
      )}
    </div>
  );
}

function CampFormModal({ hospital, city, onClose, onSaved }: { hospital: Hospital; city: string; onClose: () => void; onSaved: () => void }) {
  const [form, setForm] = useState({
    name: '',
    address: '',
    date: '',
    start_time: '09:00',
    end_time: '15:00',
    organizer: '',
  });
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.name.trim() || !form.address.trim() || !form.date) {
      setError('Name, address, and date are required.');
      return;
    }
    setSaving(true);
    setError(null);
    const { error: insertError } = await db.from('blood_camps').insert({
      name: form.name.trim(),
      address: form.address.trim(),
      city,
      date: form.date,
      start_time: form.start_time,
      end_time: form.end_time,
      organizer: form.organizer.trim() || null,
      hospital_id: hospital.id,
    });
    setSaving(false);
    if (insertError) {
      setError('Failed to schedule camp. Please try again.');
      return;
    }
    onSaved();
  };

  return (
    <Modal onClose={onClose} title="Schedule Donation Camp">
      <form onSubmit={handleSubmit} className="space-y-4">
        {error && <div className="rounded-lg bg-error-50 px-4 py-2 text-sm text-error-600">{error}</div>}
        <div>
          <label className="label">Camp Name *</label>
          <input className="input" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="Community Blood Drive" />
        </div>
        <div>
          <label className="label">Address *</label>
          <input className="input" value={form.address} onChange={(e) => setForm({ ...form, address: e.target.value })} placeholder="123 Main St" />
        </div>
        <div>
          <label className="label">Date *</label>
          <input type="date" className="input" value={form.date} onChange={(e) => setForm({ ...form, date: e.target.value })} />
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="label">Start Time *</label>
            <input type="time" className="input" value={form.start_time} onChange={(e) => setForm({ ...form, start_time: e.target.value })} />
          </div>
          <div>
            <label className="label">End Time *</label>
            <input type="time" className="input" value={form.end_time} onChange={(e) => setForm({ ...form, end_time: e.target.value })} />
          </div>
        </div>
        <div>
          <label className="label">Organizer (optional)</label>
          <input className="input" value={form.organizer} onChange={(e) => setForm({ ...form, organizer: e.target.value })} placeholder="Red Cross" />
        </div>
        <div className="flex gap-3 pt-2">
          <button type="button" onClick={onClose} className="btn-secondary flex-1">Cancel</button>
          <button type="submit" disabled={saving} className="btn-primary flex-1">
            {saving ? 'Scheduling...' : 'Schedule Camp'}
          </button>
        </div>
      </form>
    </Modal>
  );
}

/* ============ Shared ============ */

function Modal({ children, onClose, title }: { children: React.ReactNode; onClose: () => void; title: string }) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 animate-fade-in">
      <div className="absolute inset-0 bg-gray-900/40 backdrop-blur-sm" onClick={onClose} />
      <div className="relative z-10 w-full max-w-md rounded-3xl bg-white p-6 shadow-2xl animate-slide-up max-h-[90vh] overflow-y-auto">
        <div className="mb-5 flex items-center justify-between">
          <h3 className="text-lg font-bold text-gray-900">{title}</h3>
          <button onClick={onClose} className="rounded-lg p-1.5 text-gray-400 transition-colors hover:bg-gray-100 hover:text-gray-700">
            <X className="h-5 w-5" />
          </button>
        </div>
        {children}
      </div>
    </div>
  );
}

function timeAgo(dateStr: string): string {
  const diff = Date.now() - new Date(dateStr).getTime();
  const mins = Math.floor(diff / 60000);
  if (mins < 1) return 'just now';
  if (mins < 60) return `${mins}m ago`;
  const hours = Math.floor(mins / 60);
  if (hours < 24) return `${hours}h ago`;
  const days = Math.floor(hours / 24);
  return `${days}d ago`;
}
